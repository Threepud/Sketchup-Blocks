Six blocks were placed, the first five in a cross formation and then the last in the middle.
The blocks were then removed one by one (top first)