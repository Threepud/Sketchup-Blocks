A wall was built. The first block of the second layer was first placed next to the second layer.

Upon removal, the multiple blocks were removed simultaneously in the following pattern:

Layer 2: 2 x 1 
Layer 1: 2

The last block was moved to the center of the construction floor. It was then removed.