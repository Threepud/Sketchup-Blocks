A cube 2x2x2 is built. All the blocks are then removed simultaneously.
There is adjustment of the first level of blocks before the second level is built.