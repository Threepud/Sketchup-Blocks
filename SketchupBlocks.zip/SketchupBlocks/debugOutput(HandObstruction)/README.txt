Three blocks were placed: two next to each other and one on top, in the middle.
Each of the cameras were then obscured completely in turn and then there was much waving of the hands.